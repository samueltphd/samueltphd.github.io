import os

f = open('students', 'r')
students = [x.strip().replace(',', '').replace(' ', '') for x in f.readlines()]
f.close()

# initialize gradebook if empty
questions = os.listdir(os.getcwd() + '/questions')
questions = sorted(questions)

# add an entry to the student gradebook
def add_gb_entry(student, q):
	f = open(f'gradebook/{student}.csv', 'a')
	f.write(f'{q},0\n')

for student in students:
	try:
		f = open(f'gradebook/{student}.csv', 'r')
		student_questions = [x.strip() for x in f.readlines()]
		f.close()

		# add entries for any questions that you may have added
		if len(student_questions) < len(questions):
			for question in questions[len(student_questions):]:
				add_gb_entry(student, question)
	except FileNotFoundError:
		for question in questions:
			add_gb_entry(student, question)

# decide what to do next based on user input
operation = input('would you like to [grade/print] an exam: ')
assert operation == 'grade' or operation == 'print'
print(f'about to {operation}')

exam_number = '00'
if operation == 'print':
	exam_number = input('which exam are you giving [provide int]: ')
	max_questions = input('what is the most highest question you will ask them [provide int]: ')

for student in students:
	f = open(f'gradebook/{student}.csv', 'r')
	grades = [int(x.strip().split(',')[1]) for x in f.readlines()]
	f.close()
	if operation == 'print':
		print(f'about to print exam for {student}')

		student_questions = ''
		exam_questions = 0
		for g, q in zip(grades, questions):
			if int(q[1:]) > int(max_questions):
				break
			if g < 2:
				f = open(f'questions/{q}/{exam_number}', 'r')
				student_questions += f.read() + '\n\n\n'
				f.close()
				exam_questions += 1
				if exam_questions % 3 == 0:
					student_questions += '\\newpage\n'

		template = ''
		f = open('template', 'r')
		template = f.read().replace('Student Name', student).replace('REPLACE ME', student_questions).replace('CHECKINNUM', exam_number)
		f.close()

		f = open(f'exams/{exam_number}/{student}.tex', 'w')
		f.write(template)
		f.close()

		os.system(f'lualatex --output-directory=exams/{exam_number}/ exams/{exam_number}/{student}.tex ')
	else:
		assert operation == 'grade'
		print(f'about to enter grades for {student}')
		f = open(f'gradebook/{student}.csv', 'w')

		for prev_grade, q in zip(grades, questions):
			score = 0
			while True:
				try:
					score = int(input(f'enter score for {q}: '))
					break
				except ValueError:
					continue
			if score >= prev_grade:
				f.write(f'{q},{score}\n')
			else:
				f.write(f'{q},{prev_grade}\n')
		f.close()


os.system(f'rm -f exams/{exam_number}/*.aux exams/{exam_number}/*.out exams/{exam_number}/*.log exams/{exam_number}/*.tex')
